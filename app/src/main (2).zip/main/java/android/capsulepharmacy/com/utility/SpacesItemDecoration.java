package android.capsulepharmacy.com.utility;

import android.graphics.Rect;
import android.support.v7.widget.RecyclerView;
import android.view.View;


/**
 * The type Spaces item decoration.
 */
public class SpacesItemDecoration extends RecyclerView.ItemDecoration {
    /**
     * The Space.
     */
    int space = 10;

    /**
     * Instantiates a new Spaces item decoration.
     *
     * @param space the space
     */
    public SpacesItemDecoration(int space) {
        this.space = space;
    }

    @Override
    public void getItemOffsets(Rect outRect, View view, RecyclerView parent, RecyclerView.State state) {
        outRect.left = space;
        outRect.right = space;
        outRect.bottom = space;

        // Add top margin only for the first item to avoid double space between items
  //      if (parent.getChildPosition(view) == 0)
          //  outRect.top = space;

    }
}
