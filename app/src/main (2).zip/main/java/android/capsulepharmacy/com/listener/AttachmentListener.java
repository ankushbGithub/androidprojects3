package android.capsulepharmacy.com.listener;

/**
 * Created by niraj.kumar on 6/21/2018.
 */
public interface AttachmentListener {
    /**
     * On attachment clicked.
     *
     * @param position the position
     */
    void onAttachmentClicked(int position);
}
