package android.capsulepharmacy.com.listener;


/**
 * Created by niraj.kumar on 6/21/2018.
 */
public interface MyListener {
    /**
     * On attachment clicked.
     *
     * @param position the position
     */
    void onListen(int position,String type);
}

