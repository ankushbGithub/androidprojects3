package android.capsulepharmacy.com.listener;

public interface BankDetailsCardClick {
    void onBankCardClick(int pos);

}
