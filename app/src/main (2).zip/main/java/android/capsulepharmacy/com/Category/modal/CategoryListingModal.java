package android.capsulepharmacy.com.Category.modal;

public class CategoryListingModal {
    public int Id;
    public String Name;
    public String ImagePath;
    public String ImageUri;
}
