package android.capsulepharmacy.com.Category.modal;

public class SubCatListingModal {
    public int Id;
    public int CategoryId;
    public String Name;
}
