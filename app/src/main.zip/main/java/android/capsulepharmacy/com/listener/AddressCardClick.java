package android.capsulepharmacy.com.listener;

public interface AddressCardClick {
    void onAddressCardClick(int pos);
}
