package android.capsulepharmacy.com.customerModule.modal;

public class CustomerModal {
    public int Id;
    public String FirstName;
    public String LastName;
    public String DOB;
    public String Email;
    public String GSTIN;
    public String MobileNo;
    public String PhotoPath;
    public String PhotoUrl;
    public String ImagePath;
    public String ImageFile;
    public String Password;

}
