package android.capsulepharmacy.com.listener;

public interface Init {
    boolean applyLocalValidation();
}
